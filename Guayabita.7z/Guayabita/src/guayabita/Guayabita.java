/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package guayabita;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Estudiantes
 */
public class Guayabita {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println("Digite el numero de jugadores: ");
        guayabita( lecturaInt() , new ArrayList<Integer>() , 0 , 0 , 200 , 0);
    }
    
    public static void guayabita( int jugadores , ArrayList<Integer> dinero , int fase , int montoMesa , int minimo , int turno){
        
        switch (fase) {
            case 0:
                guayabita( jugadores , generarDinero( jugadores , dinero ) , 1 , montoMesa+(minimo*jugadores) , minimo , turno);
                break;
            case 1:
                guayabita( jugadores , dinero , 2 , montoMesa , minimo , turnos( jugadores ));
                break;
            case 2:
                if( montoMesa!=0 ){
                    if( dinero.get( turno-1 )==0 ){
                        if(turno==jugadores){
                            guayabita( jugadores , dinero , fase , montoMesa , minimo , 1);
                        }
                        else{
                            guayabita( jugadores , dinero , fase , montoMesa , minimo , turno+1);
                        }
                    }
                    else{
                        System.out.println("Es el turno del jugador: " + turno);
                        System.out.println("DINERO: "+ dinero.get( turno-1 ));
                        guayabitaFase2(jugadores, dinero, fase, montoMesa, minimo, turno , juego(-1, montoMesa, dinero.get( turno-1 ), minimo, 100) );
                    }
                }
                else{
                    System.out.println("EL JUEGO TERMINO");
                }
                break;
            default:
                break;
        }
        
    }
    
    public static void guayabitaFase2(int jugadores , ArrayList<Integer> dinero , int fase , int montoMesa , int minimo , int turno , int resultado){
        if(turno==jugadores){
            guayabita(jugadores, añadirResultado( jugadores, 0, dinero, new ArrayList<Integer>(), turno, resultado ), fase, montoMesa-resultado, minimo, 1);
        }
        else{
            guayabita(jugadores, añadirResultado( jugadores, 0, dinero, new ArrayList<Integer>(), turno, resultado ), fase, montoMesa-resultado, minimo, turno+1);
        }
    }
    
    public static ArrayList<Integer> añadirResultado( int jugadores , int contador , ArrayList<Integer> dinero , ArrayList<Integer> salida , int turno, int resultado){
        if( contador < jugadores ){
            if( (contador+1)==turno ){
                salida.add( dinero.get(contador) + resultado );
            }
            else{
                salida.add( dinero.get(contador) );
            }
            return añadirResultado( jugadores, contador+1, dinero, salida, turno, resultado );
        }
        else{
            return salida;
        }
    }
    
    public static int tirarDado(){
        return generarRandom( 1 , 6 );
    }
    
    public static int generarRandom( int min , int max ){
        return (int) ( Math.random()*max ) + min;
    }
    
    public static ArrayList<Integer> generarDinero( int jugadores , ArrayList<Integer> array ){
        if( jugadores > 0 ){
            array.add( 3000 );
            return generarDinero( jugadores-1 , array );
        }
        else{
            return array;
        }
    }
    
    public static int turnos( int jugadores ){
        return generarRandom( 1 , jugadores );
    }
    
    public static String lecturaString(){
        return new Scanner (System.in).nextLine().toLowerCase();
    }
    
    public static int lecturaInt(){
        return Integer.parseInt(new Scanner (System.in).nextLine());
    }
    
    public static int apostar( int montoMesa , int dinero , int minimo , int min ){
        System.out.println("Digite la cantidad a apostar: ");
        return apuesta(lecturaInt(), montoMesa, dinero, minimo, min);
    }
    
    public static int apuesta( int cantidad , int montoMesa , int dinero , int minimo , int min ){
        if( cantidad < minimo ){
            System.out.println("Digite un valor mayor a: " + minimo);
            return apuesta(lecturaInt(), montoMesa, dinero, minimo, min);
        }
        else{
            if( (cantidad > montoMesa) && (montoMesa < dinero) ){
                System.out.println("Digite un valor menor o igual a: " + montoMesa);
                return apuesta(lecturaInt(), montoMesa, dinero, minimo, min);
            }
            else if( (cantidad > dinero) && (dinero < montoMesa) ){
                System.out.println("Digite un valor menor o igual a: " + dinero);
                return apuesta(lecturaInt(), montoMesa, dinero, minimo, min);
            }
            else{
                return cantidad;
            }
        }
    }
    
    public static int resultadoApuesta(int apuesta, int valor){
        if( valor < tirarDado() ){
            System.out.println("¡Ganó! +"+apuesta);
            return apuesta;
        }
        else{
            System.out.println("Perdio. -"+apuesta);
            return -apuesta;
        }
    }
    
    public static int juego( int valor , int montoMesa , int dinero , int minimo , int min ){
        
        if( valor == -1 ){
            return juego( tirarDado() , montoMesa , dinero , minimo , min );
        }
        else{
            System.out.println("Saco: "+ valor );
            if( valor == 1 || valor == 6){
                System.out.println("Perdio. -"+minimo);
                return -minimo;
            }
            else{
                System.out.println("desea apostar? (s/n): ");
                switch(  lecturaString() ){
                    case "s":
                        return resultadoApuesta( apostar(montoMesa, dinero, minimo, min) , valor);
                    case "n":
                        System.out.println("Perdio. -"+minimo);
                        return -minimo;
                }
            }
        }
        
        return 0;
    }
    
}
